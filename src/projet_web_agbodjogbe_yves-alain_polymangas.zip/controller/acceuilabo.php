
<?php
	if(!isset($_COOKIE["user"]))
        {
        	header('Location: http://polymangas-igmangas.rhcloud.com/src/vue/signin.php');
         }

?>