<!DOCTYPE html>
<html>
    <head>
   		<title>Polymangas</title>
      	<meta http-equiv="refresh" content="0; URL=src/vue/homepage.php">
    </head>

    <body>
    
    </body>
</html>